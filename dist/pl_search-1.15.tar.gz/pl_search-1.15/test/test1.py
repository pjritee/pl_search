# Testing aspects of pl_search

import pl_search as pls
import subprocess
import contextlib
from io import StringIO
import sys
import itertools

class FailPrint(pls.Pred):
    def __init__(self, vs):
        super().__init__()
        self.vs = vs
        
    def call(self) -> bool:
        # print suppied term
        print(f'{self.vs}')
        # making the iterator empty causes this predicate to fail
        # when called
        self.choice_iterator = iter([])
        return False
        



class Print(pls.Pred):
    def __init__(self, varlst):
        super().__init__()
        self.varlst = varlst

    def call(self) -> bool:
        print(f'{self.varlst}')
        return True

    def __repr__(self):
        return f'Print({self.varlst}) : {self.continuation}'

class LoopBodyPred(pls.VarChoicePred):
    def __init__(self, pred_vars):
        # In this example var and choices are not passed in to the constructor they are
        # determined in __init__
        self.continuation = None
        self.choices = [1,2]
        for v in pred_vars:
            if pls.var(v):
                self.var = v
                break
        
    def __repr__(self):
        return f'LoopTest {self.continuation = }'
            
class LoopFactory(pls.LoopBodyFactory):

    def __init__(self, vars_):
        self.vars_ = vars_

    def loop_continues(self):
        # There are still variables for which choices need to be made
        return any(pls.var(x) for x in self.vars_)

    def make_body_pred(self):
        return LoopBodyPred(self.vars_)

v1 = pls.Var()
v2 = pls.Var()
v3 = pls.Var()


class SetChoicePred(pls.TermChoicePred):
    def __init__(self, vars_list, choices):
        choices = [list(c) for c in itertools.combinations(choices, len(vars_list))]
        super().__init__(vars_list, choices)

    


class TestExecute(pls.Pred):
    def __init__(self, v, choices, allowed, unbind = True):
        self.v = v
        self.choices = choices
        self.allowed = allowed
        self.unbind = unbind
        
    def initialize_call(self):
        self.choice_iterator = pls.VarChoiceIterator(self.v, self.choices)

    def test_choice(self):
        result = pls.engine.execute(VarChoicePred(self.v, self.allowed), self.unbind)
        return result


        
EXPECTED_OUTPUT = """All solutions using FailPrint
[1, a]
[1, b]
[2, a]
[2, b]
All solutions using Print and Fail
[1, a]
[1, b]
[2, a]
[2, b]
First Solution
[1, a]
Loop Test
[1, 1]
[1, 2]
[2, 1]
[2, 2]
Once Test Without Once
[1, 1, 1]
[1, 1, 2]
[1, 2, 1]
[1, 2, 2]
[2, 1, 1]
[2, 1, 2]
[2, 2, 1]
[2, 2, 2]
Once Test
['after once']
[1, 1, 1]
[1, 1, 2]
['after once']
[2, 1, 1]
[2, 1, 2]
Disjunction Test
['first choice', 1]
[1, 1]
['first choice', 2]
[2, 1]
[a, 1]
[b, 1]
Deterministic Predicate Test
['v1', 1]
['v2', 1]
['v3', a]
['v3', b]
['v1', 1]
['v2', 2]
['v3', a]
['v3', b]
['v1', 2]
['v2', 1]
['v3', a]
['v3', b]
['v1', 2]
['v2', 2]
['v3', a]
['v3', b]
SetChoiceIterator Test
[1, 2]
[1, 3]
[1, 4]
[2, 3]
[2, 4]
[3, 4]
NotNot Test
['after VarChoicePred call', 1]
['at end of call', X01]
Inner Execute Test with Unbind
[3]
After Inner Execute Test with Unbind v1 = X01
Inner Execute Test without Unbind
[3]
After Inner Execute Test without Unbind v1 = 3
"""

def run_tests():
    print("All solutions using FailPrint")
    pls.conjunct([
        pls.VarChoicePred(v1, [1,2]),
        pls.VarChoicePred(v2, ['a','b']),
        FailPrint([v1,v2])]).call()
    pls.trail.unbind_to(0)

    print("All solutions using Print and Fail")
    pls.conjunct([
        pls.VarChoicePred(v1, [1,2]),
        pls.VarChoicePred(v2, ['a','b']),
        Print([v1,v2]),
        pls.fail]).call()
    pls.trail.unbind_to(0)

    print("First Solution")
    pls.conjunct([
        pls.VarChoicePred(v1, [1,2]),
        pls.VarChoicePred(v2, ['a','b']),
        Print([v1,v2])]).call()
    pls.trail.unbind_to(0)

    print("Loop Test")
    body_factory = LoopFactory([v1,v2])
    pls.conjunct([
        pls.Loop(body_factory),
        Print([v1,v2]),
        pls.fail]).call()
    pls.trail.unbind_to(0)


    print("Once Test Without Once")
    pls.conjunct([
        pls.VarChoicePred(v1, [1,2]),
        pls.VarChoicePred(v2, [1,2]),
        pls.VarChoicePred(v3, [1,2]),
        FailPrint([v1,v2,v3])]).call()
    pls.trail.unbind_to(0)

    print("Once Test")
    pls.conjunct([
        pls.VarChoicePred(v1, [1,2]),
        pls.conjunct([
            pls.Once(pls.VarChoicePred(v2, [1,2])),
            Print(['after once'])]),
        pls.VarChoicePred(v3, [1,2]),
        FailPrint([v1,v2,v3])]).call()
    pls.trail.unbind_to(0)

    print("Disjunction Test")
    pls.conjunct([
        pls.DisjPred([
            pls.conjunct([
                pls.VarChoicePred(v1, [1,2]), 
                Print(["first choice", v1])]),
            pls.VarChoicePred(v1, ['a', 'b'])]),
        pls.Once(pls.VarChoicePred(v2, [1,2])),
        Print([v1,v2]),
        pls.fail]).call()
    pls.trail.unbind_to(0)

    print("Deterministic Predicate Test")
    pls.conjunct([
        pls.VarChoicePred(v1, [1,2]),
        pls.VarChoicePred(v2, [1,2]),
        Print(['v1', v1]),
        Print(['v2', v2]),
        pls.VarChoicePred(v3, ['a','b']),
        Print(['v3',v3]),
        pls.fail]).call()
    pls.trail.unbind_to(0)

    print("SetChoiceIterator Test")
    pls.conjunct([
        SetChoicePred([v1,v2], [1,2,3,4]),
        Print([v1,v2]),
        pls.fail]).call()
    pls.trail.unbind_to(0)

    print("NotNot Test")
    pls.conjunct([
        pls.NotNot(pls.conjunct([
            pls.VarChoicePred(v1, [1,2]),
            Print(["after VarChoicePred call", v1])])),
        Print(['at end of call', v1])]).call()
    pls.trail.unbind_to(0)

    print("Inner Execute Test with Unbind")
    pls.conjunct([
        TestExecute(v1, [1,2,3,4], [3]),
        Print([v1])]).call()
    print(f'After Inner Execute Test with Unbind {v1 = }')
    pls.trail.unbind_to(0)

    print("Inner Execute Test without Unbind")
    pls.conjunct([
        TestExecute(v1, [1,2,3,4], [3]),
        Print([v1])]).call()
    print(f'After Inner Execute Test without Unbind {v1 = }')
    pls.trail.unbind_to(0)

    

def test():
    test_stdout = StringIO()
    with contextlib.redirect_stdout(test_stdout):
        run_tests()
    output = test_stdout.getvalue().strip()
    print("------- TEST OUTPUT ------")
    print(output)
    if output == EXPECTED_OUTPUT.strip():
        print("------- TESTS SUCCEEDED ------")
    else:
        print("------- TESTS FAILED ------")
    
if __name__ == "__main__":
    test()
