import pl_search as pls

class FailPrint(pls.Fail):
    def __init__(self, vs):
        self.vs = vs
        
    def call_pred(self):
        return self.try_call()
        
    def try_call(self):
        print(f'{self.vs}')
        pls.engine.pop_call()
        return pls.Status.FAILURE

v1 = pls.Var()
v2 = pls.Var()

# class Member(pls.ChoiceHandler):
#     def __init__(self, args):
#         self.vs, self.allchoices = args
#         self.choices = iter([])

#     def generate_choice(self) :
#         print("generate_choice")
#         for i, v in enumerate(self.vs):
#             if pls.var(v):
#                 self.v = v
#                 self.choices = iter(self.allchoices[i])
#                 return True
                
#         self.choices = iter([])
#         return False
    
#     def make_choice(self):
#         choice = next(self.choices)
#         print(f"make choice: {self.v = } {choice = }")
#         return pls.engine.unify(self.v, choice)
    
# def solve():
#     result = pls.engine.execute(
#         pls.ChoicePred(Member,([v1], [[1,2]]),
#                        pls.ChoicePred(Member,([v2], [['a','b']]),
#                                            FailPrint())))
                                                              
class Member(pls.Pred):
    def __init__(self, v, choices):
        self.v = v
        self.choices = choices

    
    def __repr__(self):
        return f'Member({self.v}, {self.choices}) : {self.continuation}'


    def initialize_call(self):
        self.iterator = iter(self.choices)

    def try_choice(self,c):
        return pls.engine.unify(self.v, c)
    

class Print(pls.Pred):
    def __init__(self, varlst):
        self.varlst = varlst

    def initialize_call(self):
        print(f'{self.varlst}')
        self.iterator = iter([1])

    def try_choice(self, _):
        return True
      
    def __repr__(self):
        return f'Print({self.varlst}) : {self.continuation}'

class LoopTest(pls.Pred):
    def __init__(self, pred_vars):
        self.pred_vars = pred_vars

    def initialize_call(self):
        print(f'LoopTest {self}')
        self.iterator = iter([1,2])
        for v in self.pred_vars:
            if pls.var(v):
                self.v = v
                break
        
    def try_choice(self, val):
        return pls.engine.unify(self.v, val)


    def __repr__(self):
        return f'LoopTest {self.continuation = }'
            
def loop_test_fun(lst):
    return any(pls.var(x) for x in lst)
    
def solve():
    print("All solutions using FailPrint")
    pls.engine.execute(pls.conjunct([Member(v1, [1,2]),
                                     Member(v2, ['a','b']),
                                     FailPrint([v1,v2])]))
    
    print("All solutions using Print and Fail")
    pls.engine.execute(pls.conjunct([Member(v1, [1,2]),
                                     Member(v2, ['a','b']),
                                     Print([v1,v2]),
                                     pls.fail]))
    
    print("First Solution")
    pls.engine.execute(pls.conjunct([Member(v1, [1,2]),
                                     Member(v2, ['a','b']),
                                     Print([v1,v2])]))

    print("Loop Test")
    pred = pls.conjunct([pls.Loop(LoopTest, ([v1,v2],),
                                  loop_test_fun, ([v1,v2],)),
                         Print([v1,v2]),
                         pls.fail])
    #print(f'TOP_LEVEL: {pred = }')
    pls.engine.execute(pred)

    
if __name__ == "__main__":
    solve()
