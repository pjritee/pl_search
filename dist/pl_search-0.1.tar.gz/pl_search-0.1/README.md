# A package for searching and constraint programming using Prolog ideas
